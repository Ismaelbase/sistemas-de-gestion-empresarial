
cantidad = float(input("Dime la cantidad de dinero que deseas invertir: "))
beneficio = 0

if cantidad >= 0:
    if cantidad <= 10000:
        beneficio = cantidad * 0.05
        print(f"Al invertir {cantidad} euros obtienes un beneficio de {beneficio} euros.")
    elif cantidad <= 25000:
        beneficio = cantidad * 0.08
        print(f"Al invertir {cantidad} euros obtienes un beneficio de {beneficio} euros.")
    elif cantidad > 25000:
        beneficio = cantidad * 0.12
        print(f"Al invertir {cantidad} euros obtienes un beneficio de {beneficio} euros.")
else:
    print("Error, la cantidad no puede ser negativa.")

