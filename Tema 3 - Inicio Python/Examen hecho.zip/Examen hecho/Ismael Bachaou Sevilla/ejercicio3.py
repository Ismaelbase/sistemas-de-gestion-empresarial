libros = {
    'The Shining': 5.50,
    'Harry Potter and the Goblet of Fire': 10.00,
    '1984': 4.35,
    'The Lord of the Rings':14.99,
    'The Diary of Ana Frank': 24.99
  }


# a)

ordenado = sorted(libros.items(), key= lambda item:item[1], reverse=True)
print(f"El libro mas caro es {ordenado[0][0]} con un valor de {ordenado[0][1]} euros.")

# b)

mas_caro = dict()

for clave,valor in libros.items():
    encarecido = valor*0.1+valor
    mas_caro[clave] = encarecido

print(f"Diccionario normal -> {libros}")
print(f"Diccionario 10% mas caro -> {mas_caro}")

# c)

alfabetico = dict(sorted(mas_caro.items(), key= lambda item:item[0]))

print(f"Diccionario 10% mas caro en orden alfabetico -> {alfabetico}")

