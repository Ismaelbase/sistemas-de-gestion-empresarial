from dataclasses import dataclass


datos_peliculas="""titulo,genero,minutos,recaudacion
Los Vengadores,superheroes,140,367.86
La Monja,terror,100,123.57
El Reino,suspense,90,21.54
Scream 3,terror,123,300.12
Pulp fiction,drama,150,98.3
La liga de la Justicia,superheroes,120,190.12"""

# print(datos_peliculas)

# a)

lista_peliculas = datos_peliculas.split("\n")
cabecera = lista_peliculas[0].split(",")



lista_diccionario = list()


for i in range(1,len(lista_peliculas)):

    diccionario = dict()
    linea = lista_peliculas[i].split(",")

    for j in range(len(cabecera)):
        if cabecera[j] == "minutos" or cabecera[j] == "recaudacion":
            diccionario[cabecera[j]] = float(linea[j])
        else:
            diccionario[cabecera[j]] = linea[j]


    lista_diccionario.append(diccionario)

print(f"LISTA DICCIONARIO -> {lista_diccionario}")

# b)

opcion = -1

while opcion != 0:

    print("0 - Salir.")
    print("1 - Mostrar ordenada la lista de peliculas ordenadas de mayor a menor por minutos de duracion.")
    print("2 - Mostrar el nombre de la pelicula que ha recaudado menos dinero.")
    print("3 - Convertir la estructura en un string similar al del origen y mostrarlo por pantalla.")

    opcion = int(input("Elige una opcion: "))

    if opcion == 1:
        print("Peliculas ordenadas por minutos: ")
        print("")
        ordenada_minutos = sorted(lista_diccionario, key= lambda item: item.get("minutos"), reverse=True)
        print(ordenada_minutos)
    elif opcion == 2:
        print("Pelicula que ha recaudado menos dinero: ")
        print("")
        ordenada_recaudacion = sorted(lista_diccionario, key= lambda item: item.get("recaudacion"))
        print(ordenada_recaudacion[0].get("titulo"))
    elif opcion == 3:
        print("Estructura transformada a String: ")
        print("")
        texto = str()
        for clave in lista_diccionario[0]:
            texto += clave+","
        texto = texto[:-1]
        lista_cabecera = texto.split(",")
        texto += "\n"

        for pelicula in lista_diccionario:
            for i in range(len(lista_cabecera)):
                texto += str(pelicula.get(lista_cabecera[i]))+","
            texto = texto[:-1]
            texto += "\n"

        comillas = "\"\"\""
        texto = texto[:-1]
        texto += comillas
        comillas += texto
        texto = comillas
        print(texto)
        print("")
    elif opcion == 0:
        print("Adios.")
    else:
        print("Elige una opcion correcta.")