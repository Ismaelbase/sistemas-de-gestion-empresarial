import random

# a)

cantidad_dados = int(input("Dime un numero de dados a tirar: "))

if cantidad_dados >= 0:

    tiradas_j1 = list()
    tiradas_j2 = list()

    for i in range(cantidad_dados):
        tirada_j1 = random.randint(1,6)
        print(f"Tirada {i} jugador 1 -> {tirada_j1}")
        tirada_j2 = random.randint(1,6)
        print(f"Tirada {i} jugador 2 -> {tirada_j2}")

        tiradas_j1.append(tirada_j1)
        tiradas_j2.append(tirada_j2)

    suma_j1 = max(tiradas_j1)+min(tiradas_j1)
    suma_j2 = max(tiradas_j2)+min(tiradas_j2)

    if suma_j2 == suma_j1:
        print(f"La suma de la mayor y menor tirada del Jugador 1 es [{suma_j1}] y la del Jugador 2 [{suma_j2}] -> Empate.")
    elif suma_j2 > suma_j1:
        print(f"La suma de la mayor y menor tirada del Jugador 1 es [{suma_j1}] y la del Jugador 2 [{suma_j2}] -> Gana el Jugador 2.")
    elif suma_j1 > suma_j2:
        print(f"La suma de la mayor y menor tirada del Jugador 1 es [{suma_j1}] y la del Jugador 2 [{suma_j2}] -> Gana el Jugador 1.")

else:
    print("Error, la cantidad de dados a tirar no puede ser negativa.")


# b)
print("\n\n\n")

caracteres = "@$_ABCDEFRSTUVXYZghijklmnpq"

longitud = int(input("Dime la longitud de la contraseña a generar: "))

lista_caracteres = list(caracteres)

password = ""

for i in range(longitud):
    password += random.choice(lista_caracteres)

print(f"La contraseña generada es: {password}")